package com.example.tugas2;

public class ModalMahasiswa {

    private String _kelas, _nama, _hari, _jam;

    public ModalMahasiswa (String kelas, String nama, String hari, String jam){
        this._kelas = kelas;
        this._nama = nama;
        this._hari = hari;
        this._jam = jam;
    }
    public ModalMahasiswa(){
    }

    public void set_kelas (String kelas){
        this._kelas = kelas;
    }

    public String get_kelas(){
        return this._kelas;
    }

    public void set_nama (String nama){
        this._nama = nama;
    }

    public String get_nama(){
        return this._nama;
    }

    public void set_hari (String hari){
        this._hari= hari;
    }

    public String get_hari(){
        return this._hari;
    }

    public void set_jam (String jam){
        this._jam = jam;
    }

    public String get_jam(){
        return this._jam;
    }

}
