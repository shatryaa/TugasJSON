package com.example.tugas2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainCreate extends AppCompatActivity {

    private DatabaseHandler db;
    private EditText Ekelas, Emk, Ehari, Ejam;
    private String Skelas, Smk, Shari, Sjam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        db = new DatabaseHandler(this);

        Ekelas = (EditText) findViewById(R.id.create_kelas);
        Emk = (EditText) findViewById(R.id.create_mk);
        Ehari = (EditText) findViewById(R.id.create_hari);
        Ejam = (EditText) findViewById(R.id.create_jam);

        Button btnCreate = (Button) findViewById(R.id.create_btn);
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Skelas = String.valueOf(Ekelas.getText());
                Smk = String.valueOf(Emk.getText());
                Shari = String.valueOf(Ehari.getText());
                Sjam = String.valueOf(Ejam.getText());

                if (Skelas.equals("")) {
                    Ekelas.requestFocus();
                    Toast.makeText(MainCreate.this, "Silahkan isi Kelas", Toast.LENGTH_SHORT).show();
                } else if (Smk.equals("")) {
                    Emk.requestFocus();
                    Toast.makeText(MainCreate.this, "Silahkan Isi Mata Kuliah", Toast.LENGTH_SHORT).show();
                }else if (Shari.equals("")) {
                    Ehari.requestFocus();
                    Toast.makeText(MainCreate.this, "Silahkan Isi Mata Kuliah", Toast.LENGTH_SHORT).show();
                }else if (Sjam.equals("")){
                    Ejam.requestFocus();
                    Toast.makeText(MainCreate.this, "Silahkan Isi Mata Kuliah", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
