package com.example.tugas2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "db_kampus";

    private static final String tb_mahasiswa = "tb_mahasiswa";

    private static final String tb_mahasiswa_kelas = "tb_kelas";
    private static final String tb_mahasiswa_nama = "tb_nama";
    private static final String tb_mahasiswa_hari = "tb_hari";
    private static final String tb_mahasiswa_jam = "tb_jam";

    private static final String CREATE_TABEL_MAHASISWA = "CREATE TABLE" +tb_mahasiswa + "("
            + tb_mahasiswa_kelas + "INTEGER PRIMARY KEY ,"
            + tb_mahasiswa_hari + "TEXT ,"
            + tb_mahasiswa_nama + "TEXT ,"
            + tb_mahasiswa_jam + "VARCHAR" + ")";


    public DatabaseHandler (Context context){
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABEL_MAHASISWA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void CreateMahasiswa (ModalMahasiswa mdNotif){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(tb_mahasiswa_kelas, mdNotif.get_kelas());
        values.put(tb_mahasiswa_nama, mdNotif.get_nama());
        values.put(tb_mahasiswa_hari, mdNotif.get_hari());
        values.put(tb_mahasiswa_jam, mdNotif.get_jam());
        db.insert(tb_mahasiswa, null, values);
        db.close();
    }
}
